const {Cache: CustomThemeSettingsCache} = require('@tryghost/custom-theme-settings-service');

module.exports = new CustomThemeSettingsCache();
