const loader = require('./loader');

module.exports = loader.loadNconf();
