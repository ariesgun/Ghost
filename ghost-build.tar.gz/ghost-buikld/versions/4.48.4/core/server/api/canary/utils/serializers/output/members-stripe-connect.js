module.exports = {
    all() {
        // No response
        return;
    }
};
