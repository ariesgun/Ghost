const debug = require('@tryghost/debug')('api:canary:utils:serializers:output:offers');

module.exports = {
    all() {
        debug('all');
        // Offers has frame.response already set
    }
};
