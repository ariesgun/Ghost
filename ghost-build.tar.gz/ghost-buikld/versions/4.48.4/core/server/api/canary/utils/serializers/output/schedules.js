module.exports = {
    all(data, apiConfig, frame) {
        frame.response = data;
    }
};
