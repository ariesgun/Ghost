const url = require('../utils/url');

module.exports = (path) => {
    return url.forImage(path);
};
