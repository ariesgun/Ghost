module.exports = {
    get spamPrevention() {
        return require('./spam-prevention');
    }
};
