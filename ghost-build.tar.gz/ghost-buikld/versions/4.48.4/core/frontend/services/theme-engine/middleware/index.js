module.exports = [
    require('./ensure-active-theme'),
    require('./update-global-template-options'),
    require('./update-local-template-data'),
    require('./update-local-template-options')
];
