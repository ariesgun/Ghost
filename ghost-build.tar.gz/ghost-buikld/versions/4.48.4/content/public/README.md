# Content / Public

Ghost will store any built assets here. This goes hand in hand with core/frontend/public where static assets are stored.
